import type React from "react"
interface DashboardShellProps {
  children: React.ReactNode
}

export function DashboardShell({ children }: DashboardShellProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2 font-semibold">
            <span className="text-xl">Lost & Found</span>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <div className="container grid items-start gap-4 py-8">{children}</div>
      </main>
    </div>
  )
}

