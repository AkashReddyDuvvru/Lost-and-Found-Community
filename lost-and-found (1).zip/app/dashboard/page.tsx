"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { LogOut, Plus, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ItemCard } from "@/components/item-card"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"

// Mock data for lost items
const mockItems = [
  {
    id: "1",
    title: "Blue Backpack",
    description: "Lost at Central Park on June 15th. Contains laptop and books.",
    location: "Central Park, New York",
    date: "2023-06-15",
    status: "lost",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: "2",
    title: "iPhone 13 Pro",
    description: "Lost at the coffee shop on Main Street. Has a blue case.",
    location: "Starbucks, Main Street",
    date: "2023-06-18",
    status: "lost",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: "3",
    title: "Gold Watch",
    description: "Found near the library entrance. Brand is Timex.",
    location: "Public Library",
    date: "2023-06-20",
    status: "found",
    image: "/placeholder.svg?height=200&width=300",
  },
]

export default function DashboardPage() {
  const [items, setItems] = useState(mockItems)
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()

  // Load items from localStorage on component mount
  useEffect(() => {
    const storedItems = localStorage.getItem("lostAndFoundItems")
    if (storedItems) {
      setItems(JSON.parse(storedItems))
    } else {
      // Initialize localStorage with mock data if empty
      localStorage.setItem("lostAndFoundItems", JSON.stringify(mockItems))
    }
  }, [])

  const filteredItems = items.filter(
    (item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.location.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const lostItems = filteredItems.filter((item) => item.status === "lost")
  const foundItems = filteredItems.filter((item) => item.status === "found")

  const handleLogout = () => {
    router.push("/")
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Dashboard" text="Manage your lost and found items">
        <div className="flex items-center gap-2">
          <Link href="/dashboard/new-item">
            <Button className="gap-1">
              <Plus className="h-4 w-4" /> New Item
            </Button>
          </Link>
          <Button variant="outline" size="icon" onClick={handleLogout}>
            <LogOut className="h-4 w-4" />
            <span className="sr-only">Logout</span>
          </Button>
        </div>
      </DashboardHeader>
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search items..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Items</TabsTrigger>
            <TabsTrigger value="lost">Lost Items</TabsTrigger>
            <TabsTrigger value="found">Found Items</TabsTrigger>
          </TabsList>
          <TabsContent value="all" className="space-y-4">
            {filteredItems.length === 0 ? (
              <div className="flex h-[200px] flex-col items-center justify-center rounded-md border border-dashed">
                <p className="text-sm text-muted-foreground">No items found</p>
                <Link href="/dashboard/new-item" className="mt-2">
                  <Button variant="link" size="sm">
                    Add a new item
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {filteredItems.map((item) => (
                  <ItemCard key={item.id} item={item} />
                ))}
              </div>
            )}
          </TabsContent>
          <TabsContent value="lost" className="space-y-4">
            {lostItems.length === 0 ? (
              <div className="flex h-[200px] flex-col items-center justify-center rounded-md border border-dashed">
                <p className="text-sm text-muted-foreground">No lost items found</p>
                <Link href="/dashboard/new-item" className="mt-2">
                  <Button variant="link" size="sm">
                    Report a lost item
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {lostItems.map((item) => (
                  <ItemCard key={item.id} item={item} />
                ))}
              </div>
            )}
          </TabsContent>
          <TabsContent value="found" className="space-y-4">
            {foundItems.length === 0 ? (
              <div className="flex h-[200px] flex-col items-center justify-center rounded-md border border-dashed">
                <p className="text-sm text-muted-foreground">No found items found</p>
                <Link href="/dashboard/new-item" className="mt-2">
                  <Button variant="link" size="sm">
                    Report a found item
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {foundItems.map((item) => (
                  <ItemCard key={item.id} item={item} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardShell>
  )
}

