"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { CalendarIcon, MapPin, ArrowLeft, Edit, Trash2, Phone, Mail, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Mock data for lost items
const mockItems = [
  {
    id: "1",
    title: "Blue Backpack",
    description: "Lost at Central Park on June 15th. Contains laptop and books.",
    location: "Central Park, New York",
    date: "2023-06-15",
    status: "lost",
    image: "/placeholder.svg?height=200&width=300",
    contactDetails: {
      name: "John Doe",
      phone: "+1 (555) 123-4567",
      email: "john@example.com",
    },
  },
  {
    id: "2",
    title: "iPhone 13 Pro",
    description: "Lost at the coffee shop on Main Street. Has a blue case.",
    location: "Starbucks, Main Street",
    date: "2023-06-18",
    status: "lost",
    image: "/placeholder.svg?height=200&width=300",
    contactDetails: {
      name: "Jane Smith",
      phone: "+1 (555) 987-6543",
      email: "jane@example.com",
    },
  },
  {
    id: "3",
    title: "Gold Watch",
    description: "Found near the library entrance. Brand is Timex.",
    location: "Public Library",
    date: "2023-06-20",
    status: "found",
    image: "/placeholder.svg?height=200&width=300",
    contactDetails: {
      name: "Mike Johnson",
      phone: "+1 (555) 456-7890",
      email: "mike@example.com",
    },
  },
]

export default function ItemDetailPage({ params }: { params: { id: string } }) {
  const [item, setItem] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [contactDialogOpen, setContactDialogOpen] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    // Get items from localStorage
    const storedItems = localStorage.getItem("lostAndFoundItems")
    if (storedItems) {
      const items = JSON.parse(storedItems)
      const foundItem = items.find((item: any) => item.id === params.id)
      setItem(foundItem || null)
    } else {
      // Fallback to mock data if localStorage is empty
      const foundItem = mockItems.find((item) => item.id === params.id)
      setItem(foundItem || null)
    }
    setIsLoading(false)
  }, [params.id])

  const handleDelete = () => {
    // Get items from localStorage
    const storedItems = localStorage.getItem("lostAndFoundItems")
    if (storedItems) {
      const items = JSON.parse(storedItems)
      // Filter out the item to delete
      const updatedItems = items.filter((i: any) => i.id !== params.id)
      // Save back to localStorage
      localStorage.setItem("lostAndFoundItems", JSON.stringify(updatedItems))
    }

    toast({
      title: "Item deleted",
      description: "The item has been deleted successfully.",
    })
    router.push("/dashboard")
  }

  const handleOpenMap = () => {
    // Check if the location is coordinates
    if (item.location && item.location.includes(",")) {
      const [lat, lng] = item.location.split(",").map((coord) => coord.trim())
      window.open(`https://maps.google.com/?q=${lat},${lng}`, "_blank")
    } else {
      // If not coordinates, search for the location name
      window.open(`https://maps.google.com/maps?q=${encodeURIComponent(item.location)}`, "_blank")
    }
  }

  if (isLoading) {
    return (
      <DashboardShell>
        <DashboardHeader heading="Item Details" />
        <div className="flex items-center justify-center p-8">
          <p>Loading item details...</p>
        </div>
      </DashboardShell>
    )
  }

  if (!item) {
    return (
      <DashboardShell>
        <DashboardHeader heading="Item Not Found" />
        <div className="flex flex-col items-center justify-center p-8">
          <p className="mb-4 text-muted-foreground">The requested item could not be found.</p>
          <Button onClick={() => router.push("/dashboard")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
          </Button>
        </div>
      </DashboardShell>
    )
  }

  const formattedDate = new Date(item.date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  const hasContactDetails =
    item.contactDetails && (item.contactDetails.name || item.contactDetails.phone || item.contactDetails.email)

  return (
    <DashboardShell>
      <DashboardHeader heading="Item Details">
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => router.push("/dashboard")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back
          </Button>
          <Button variant="outline" onClick={() => router.push(`/dashboard/edit-item/${item.id}`)}>
            <Edit className="mr-2 h-4 w-4" /> Edit
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive">
                <Trash2 className="mr-2 h-4 w-4" /> Delete
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the item.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </DashboardHeader>
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardContent className="p-6">
            <div className="aspect-video w-full overflow-hidden rounded-md">
              <img src={item.image || "/placeholder.svg"} alt={item.title} className="h-full w-full object-cover" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">{item.title}</h2>
                <Badge variant={item.status === "lost" ? "destructive" : "default"}>
                  {item.status === "lost" ? "Lost" : "Found"}
                </Badge>
              </div>
              <p className="text-muted-foreground">{item.description}</p>
              <div className="space-y-2 rounded-md bg-muted p-4">
                <div className="flex items-center text-sm">
                  <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
                  <span className="flex-1">{item.location}</span>
                  <Button variant="ghost" size="sm" className="ml-2 h-7 px-2 text-xs" onClick={handleOpenMap}>
                    View on Map
                  </Button>
                </div>
                <div className="flex items-center text-sm">
                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                  <span>{formattedDate}</span>
                </div>
              </div>

              {hasContactDetails && (
                <div className="pt-4">
                  <h3 className="mb-2 font-semibold">Contact Information</h3>
                  {item.contactDetails.name && (
                    <div className="flex items-center text-sm mb-2">
                      <User className="mr-2 h-4 w-4 text-muted-foreground" />
                      <span>{item.contactDetails.name}</span>
                    </div>
                  )}
                  {item.contactDetails.phone && (
                    <div className="flex items-center text-sm mb-2">
                      <Phone className="mr-2 h-4 w-4 text-muted-foreground" />
                      <span>{item.contactDetails.phone}</span>
                    </div>
                  )}
                  {item.contactDetails.email && (
                    <div className="flex items-center text-sm mb-2">
                      <Mail className="mr-2 h-4 w-4 text-muted-foreground" />
                      <span>{item.contactDetails.email}</span>
                    </div>
                  )}

                  <Dialog open={contactDialogOpen} onOpenChange={setContactDialogOpen}>
                    <DialogTrigger asChild>
                      <Button className="mt-4 w-full">Contact Owner</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Contact Information</DialogTitle>
                        <DialogDescription>
                          Use the following information to contact the {item.status === "lost" ? "owner" : "finder"} of
                          this item.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        {item.contactDetails.name && (
                          <div className="flex items-center">
                            <User className="mr-2 h-5 w-5" />
                            <span className="font-medium">{item.contactDetails.name}</span>
                          </div>
                        )}
                        {item.contactDetails.phone && (
                          <div className="flex items-center">
                            <Phone className="mr-2 h-5 w-5" />
                            <a href={`tel:${item.contactDetails.phone}`} className="font-medium text-primary underline">
                              {item.contactDetails.phone}
                            </a>
                          </div>
                        )}
                        {item.contactDetails.email && (
                          <div className="flex items-center">
                            <Mail className="mr-2 h-5 w-5" />
                            <a
                              href={`mailto:${item.contactDetails.email}`}
                              className="font-medium text-primary underline"
                            >
                              {item.contactDetails.email}
                            </a>
                          </div>
                        )}
                      </div>
                      <DialogFooter>
                        <Button onClick={() => setContactDialogOpen(false)}>Close</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              )}

              {!hasContactDetails && (
                <div className="pt-4">
                  <h3 className="mb-2 font-semibold">Contact Information</h3>
                  <p className="text-sm text-muted-foreground">No contact information provided for this item.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}

